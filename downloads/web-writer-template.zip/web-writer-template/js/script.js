// Write your part of speech array here

// Create your wordPicker function here

// A setInterval() to run the function every 2 seconds
window.setInterval(function() {
    // Run your function here
}, 2000);

// Run your function when the page first loads